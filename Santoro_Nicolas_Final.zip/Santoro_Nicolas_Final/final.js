$(document).ready(function() {
  

  
  //j query
$("#submit").text("Submit!");
    
    
    document.getElementById('submit').onclick = function myPlayer() {
    var selected = document.querySelector('input[type=radio][name=player]:checked');
    alert(selected.value + ' is an awesome player!');
    
    if (selected.value == "Jalen Smith") {
        alert("Did you know that Jalen Smith went to Mount Saint Joseph High School in Baltimore, with fellow Terrapin, Darryl Morsell?");
    }
    
    else if (selected.value == "Len Bias") {
        alert("Did you know that Len Bias has a law named after him?");
    }
    
    else if (selected.value == "Stefon Diggs") {
        alert("Did you know that Stefon Diggs was runner-up for Maryland HS Football Gatorade Player of the Year in 2010?");
    }
    else {
        alert("No player was selected. Try Again.");
    }
};

//Staying Home://
/*function playSong() {
        var audio = document.getElementById("marylandsong");
        audio.play('marylandfight.mp3');
      }*/

      
});